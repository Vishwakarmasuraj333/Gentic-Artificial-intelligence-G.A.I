# Calculate the output of neural net using both binary and bipolar sigmoidal function

import numpy as np

def binary_sigmoid(x):
    return 1 / (1 + np.exp(-x))

def bipolar_sigmoid(x):
    return (2 / (1 + np.exp(-x))) - 1

def calculate_neural_net_output(inputs, weights, biases, activation_function):
    net_input = np.dot(inputs, weights) + biases
    return activation_function(net_input)

if __name__ == "__main__":
    inputs = np.array([0.5, -0.2, 0.1])

    weights = np.array([
        [0.4, 0.3, 0.5],
        [-0.3, 0.8, -0.6]
    ]).T

    biases = np.array([0.1, -0.1])

    binary_output = calculate_neural_net_output(
        inputs, weights, biases, binary_sigmoid
    )
    print("Binary Sigmoid Output:", binary_output)

    bipolar_output = calculate_neural_net_output(
        inputs, weights, biases, bipolar_sigmoid
    )
    print("Bipolar Sigmoid Output:", bipolar_output)
