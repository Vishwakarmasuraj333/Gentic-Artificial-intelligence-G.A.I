#Aim: Membership and Identity Operators is, is not
x = 5

if type(x) is int:
    print("true")
else:
    print("false")
